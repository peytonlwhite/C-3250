
#ifndef WGRAPH_H
#define WGRAPH_H
#include <stdexcept>
#include <fstream>

class WGraph
{


public:
	int mVertices;
	int* mGraph;
	WGraph(int);                      // Builds a blank matrix that is m * m

	WGraph();
	WGraph(const WGraph&);     // Copy Constructor
	~WGraph();                        // Destructor

	WGraph& operator=(const WGraph&);

	void copy(const WGraph&);         // Copies a graph (requires a for loop!)
	void checkForVertexInRange(int) const;   // Checks for a vertex in range

	bool operator==(const WGraph&) const;
	// Requires a loop.

	int GetNumVertices() const;              // Returns mVertices

	virtual void set(int, int, int);

	virtual void set(int, int);
	int get(int, int) const;                 // Returns mGraph at cell (i,j)



	bool isSymmetric() const;                // Returns true if every elements at (i,j) is identical to (j,i)
	bool isAntisymmetric() const;            // Returns true if element at (i,j) is 1 and element (j,i)
											 // is 0 (provided that i != j)

											 // Each of these methods require a for loop!!!! hint
	WGraph transpose() const;         // Builds a new matrix which is transpose of this matrix get help!
	bool isReflexive() const;                // Returns true if all elements along the diagonal are > 0
	friend std::ostream& operator<<(std::ostream& os, const WGraph& g); // Visualizes the graph 
};


#endif