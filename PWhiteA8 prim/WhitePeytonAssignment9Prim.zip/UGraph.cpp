#include "UGraph.h"
#include "Wgraph.h"
#include <iostream>


// deafult that sets graph
UndirectedGraph::UndirectedGraph(int mVerts)
 {
 mVertices = mVerts;
 int uCapicity = mVerts * mVerts;
 mGraph = new int[mVertices * mVertices];
 for (int i = 0; i < uCapicity; i++) {
	 mGraph[i] = 0;
 }
	}

//  has set two SE but gets graph size set
void UndirectedGraph::set(int start, int end) {
	mGraph[start * mVertices + end] = 0;

}

//sets using three ints SEW but first checks for vertex in range
void UndirectedGraph::set(int start, int end, int weight) {
	checkForVertexInRange(end);
	checkForVertexInRange(start);
	mGraph[start * mVertices + end] = weight;
	mGraph[end * mVertices + start] = weight;
}

// does prim :) use word document for Phesduocode took 3 tries!  
UndirectedGraph UndirectedGraph::prim() {
    //Create a blank graph named mst with a matching number of vertices to this graph.
	UndirectedGraph mst(mVertices);

	//Set a starting vertex to be 0.
	int start = 0;

	// create an integer array of length Number of Vertices named distance.
	
	int* distance = new int[mVertices];
	// Create an integer array of length Number of Vertices named adjacent.
	int * adjacent = new int[mVertices];
	// Create a Boolean array of length Number of Vertices named available.
	bool* available = new bool[mVertices];
	
	// create for loop to make distance max, adjacent -1, and available to true
	for (int i = 0; i < mVertices; i++) {
		distance[i] = INT_MAX;
		adjacent[i] = -1;
		available[i] = true;
	}

	//Set distance[start] to be 0.
	distance[start] = 0;
	//Create an integer availableCount set to Number of Vertices
	int availableCount = mVertices;
    //while availableCount greater than 0
	while (availableCount > 0) {

		//index position is named u
		int u = 0;


		int minElement = INT_MAX;
		for (int v = 0; v < mVertices; v++) {
			if (available[v] == true && distance[v] < minElement) {

				u = v;

				minElement = distance[v];
			}
		}

		{
			if (u != start) {
			mst.set(u, adjacent[u], get(u, adjacent[u]));
		}



			for (int v = 0; v < mVertices; v++) {
				if (get(u, v) > 0 && get(u, v) < distance[v])
				{

					distance[v] = get(u, v);
					adjacent[v] = u;
				}
			}
		//Set available[u] to be false.
		available[u] = false;
		//Decrement availableCount by 1
		availableCount--;
		}
	}
	//For each vertex v. look at word document
	for (int i = 0; i < mVertices; i++) {
		for (int j = 0; j < mVertices; j++) {
			set(i, j, mst.get(i, j));
		}
	}
	// return it
	return mst;
};

// This will require a fancy for-loop.
int UndirectedGraph::getSumEdgeWeights() {

	int edgeweights = 0;
	for (int i = 0; i < mVertices; i++) {
		for (int j = 0; j < mVertices; j++) {
			edgeweights += get(i, j);
		}
	}
	return  edgeweights / 2;

}

// had to make to print Ugraph instead of Wgraph
std::ostream& operator<<(std::ostream& os, const UndirectedGraph& ug)
{
	for (int i = 0; i < ug.mVertices; i++) {

		for (int j = 0; j < ug.mVertices; j++) {
			os << ug.get(i, j) << " ";
		}
		std::cout << "\n";
	}
	return os;
}