#ifndef UGRAPH_H
#define UGRAPH_H
#include "Wgraph.h"

// word document MST(8)
class UndirectedGraph : public WGraph
{
public:
	UndirectedGraph(int mVerts);

	void set(int, int, int);        // Sets index i,j to weight AND index j,i to weight
									// First param: i
									// Second param: j
									// Third param: weight
	void set(int, int);             // Calls set(i, j, 1)

	int getSumEdgeWeights();        // Comutes the sum of the edge weights

	friend std::ostream& operator<<(std::ostream& os, const UndirectedGraph& g);	// go to Wgraph used to print graph							
									// This will require a fancy for-loop.
	UndirectedGraph prim();         // The big one. See below.
};

#endif
