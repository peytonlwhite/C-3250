#include <iostream>
#include "Wgraph.h"
#include "UGraph.h"
/*
Peyton White
3250
assignment 9 graphs and prim
4/25/2018
this program creates a Ugraph and allows user to create verts and edges and tells them if it is reflexive and at the end gives the 
result of Mininmum spanning tree

*/


void menu();

int main() {

	menu();


	std::cout << "\n";
	std::cout << "Thank you for using Peyton's program \n";
	system("pause");
	return 0;
}

void menu() {

	// user chooses num of edges and vertices
	int weight;
	int numOfEdges;
	int numOfVert;
	std::cout << "Enter a number of vertices in the graph: ";
	std::cin >> numOfVert;
	std::cout << "Enter a number of edges in the graph: ";
	std::cin >> numOfEdges;

	// graph.h instance that sets size with vertices of user pick
	UndirectedGraph graph(numOfVert);
	// this instance is used for the transpose call in the menu to pass through the operator call
	UndirectedGraph transM(numOfVert);
	// lets user choose vertexes
	int choiceStart;
	int choiceEnd;
	for (int i = 0; i < numOfEdges; i++) {
		std::cout << "Enter a starting vertex: ";
		std::cin >> choiceStart;
		std::cout << "Enter a ending vertex: ";
		std::cin >> choiceEnd;
		std::cout << "Enter a weight: ";
		std::cin >> weight;
		// sets the graph
		graph.set(choiceStart, choiceEnd,weight);
		graph.set(choiceEnd, choiceStart, weight);
	}
	// uses operator to visualize graph 
	operator<<(std::cout, graph);
	
	std::cout << "Reflexive?: ";
	if (graph.isReflexive()) {
		std::cout << "Yes \n";
	}
	else {
		std::cout << "No \n";
	}

	std::cout << "Symmetric?: ";
	if (graph.isSymmetric()) {
		std::cout << "Yes \n";
	}
	else {
		std::cout << "No \n";
	}

	std::cout << "AntiSymmetric?: ";
	if (graph.isAntisymmetric()) {
		std::cout << "Yes \n";
	}
	else {
		std::cout << "No \n";
	}

	// calls the prim function and puts it in a var and passes it through the operator to print prim graph
	std::cout << "Minimum Spanning Graph: \n";
	transM = graph.prim();
	operator<<(std::cout, transM);
	int sumOfEdgeWeights = graph.getSumEdgeWeights();
	std::cout << "Sum of Edge Weights: " << sumOfEdgeWeights << "\n";



}