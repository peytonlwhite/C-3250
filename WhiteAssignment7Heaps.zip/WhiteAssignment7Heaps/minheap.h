#ifndef MINHEAP_H
#define MINHEAP_H
#include <stdexcept>
#include "vector.hpp"




class MinHeap {

private:

	vector<int> mVector;

	void checkForEmpty() const;     // throws error on empty heap
	void heapifyNode(int);          //heapifies one subtree
	void swap(int, int);            //swaps two positions in vector


public:
	MinHeap();                      // empty default constructor 
	void insert(int);               // inserts always maintain heap
	void push_back(int);            // calls push back
	int remove();                    // removes top element
	bool isEmpty() const;            // return true if heap is empty
	int peek() const;                // returns the top elemnet at 0
	int getParentIndex(int);
	int getLeftChildIndex(int);
	int getRightChildIndex(int);



};
#endif 


