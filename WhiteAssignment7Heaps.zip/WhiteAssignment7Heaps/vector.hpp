#ifndef VECTOR_H
#define VECTOR_H
#include <stdexcept>

template <class T>
class vector {
private:
	T* mArray;
	int mSize;
	int mCapacity;
	int mAssignments;
	void clear();
	void allocate(int capacity);
	void init(int capacity);
	void copy(const vector&);
	void resize(int);

public:
	vector();
	vector(int);
	vector(const vector<T>&);
	vector<T>& operator=(const vector<T>&);
	~vector();
	int size() const;
	int getCapacity() const;
	int getAssignmentCount() const;
	T at(int) const;
	T& operator[](int);
	const T& operator[](int) const;
	void push_back(const T);
	T pop_back();
	void shrink_to_fit();
	void sort();
	bool isSorted() const;
};

template <class T>
void vector<T>::clear() {
	delete[] mArray;
}

template <class T>
void vector<T>::allocate(int capacity) {
	mCapacity = capacity;
	mArray = new T[mCapacity];
}

template <class T>
void vector<T>::init(int capacity) {
	if (capacity < 10) {
		capacity = 10;
	}

	mSize = 0;
	mAssignments = 0;
	allocate(capacity);
}

template <class T>
void vector<T>::copy(const vector& aVector) {
	mSize = aVector.mSize;
	mAssignments = aVector.mAssignments;
	allocate(aVector.mCapacity);

	int i;
	for (i = 0; i < mSize; i++) {
		mArray[i] = aVector.mArray[i];
	}
}

template <class T>
void vector<T>::resize(int size) {
	if (size < mSize) {
		throw std::invalid_argument("Cannot remove elements using resize.");
	}

	if (size > mSize) {
		T* nextArray = new T[size];

		for (int i = 0; i < mSize; i++) {
			nextArray[i] = mArray[i];
			mAssignments++;
		}

		clear();
		mArray = nextArray;
		mCapacity = size;
	}
}

template <class T>
vector<T>::vector() {
	init(10);
}

template <class T>
vector<T>::vector(int capacity) {
	init(capacity);
}

template <class T>
vector<T>::vector(const vector<T>& aVector) {
	copy(aVector);
}

template <class T>
vector<T>& vector<T>::operator=(const vector<T>& aVector) {
	if (this != &aVector) {
		clear();
		copy(aVector);
	}
	return *this;
}

template <class T>
vector<T>::~vector() {
	clear();
}

template <class T>
int vector<T>::size() const {
	return mSize;
}

template <class T>
int vector<T>::getCapacity() const {
	return mCapacity;
}

template <class T>
int vector<T>::getAssignmentCount() const {
	return mAssignments;
}

template <class T>
T vector<T>::at(int index) const {
	if (index < 0 || index >= mSize) {
		throw std::invalid_argument("Index out of bounds.");
	}

	return mArray[index];
}

template <class T>
T& vector<T>::operator[](int index) {
	return mArray[index];
}

template <class T>
const T& vector<T>::operator[](int index) const {
	return mArray[index];
}

template <class T>
void vector<T>::push_back(const T value) {
	if (mSize >= mCapacity) {
		resize(mCapacity * 2);
	}

	mArray[mSize] = value;
	mSize++;
	mAssignments++;
}

template <class T>
T vector<T>::pop_back() {
	if (mSize == 0) {
		throw std::invalid_argument("Cannot move from empty vector.");
	}

	mSize--;
	return mArray[mSize];
}

template <class T>
void vector<T>::shrink_to_fit() {
	resize(size);
}

template <class T>
void vector<T>::sort() {
	for (int i = 0; i < mSize - 1; i++) {
		for (int j = i + 1; j < mSize; j++) {
			if (mArray[j] < mArray[i]) {
				T temp = mArray[i];
				mArray[i] = mArray[j];
				mArray[j] = temp;
			}
		}
	}
}

template <class T>
bool vector<T>::isSorted() const {
	bool sorted = true;
	for (int i = 1; i < mSize; i++) {
		if (mArray[i - 1] > mArray[i]) {
			sorted = false;
		}
	}
	return sorted;
}

#endif
