#include "minheap.h"
#include <iostream>


void MinHeap::checkForEmpty() const {

	if (mVector.size() == 0) {
		throw std::invalid_argument("The vector is empty");
	}

}
void MinHeap::heapifyNode(int num) {
	
	
	int leftChild = getLeftChildIndex(num);
	int rightChild = getRightChildIndex(num);
	int isLowest = num;
	
	if (leftChild < mVector.size() && mVector[leftChild] < mVector[isLowest]) {

		isLowest = leftChild;
	}


	if (rightChild < mVector.size() && mVector[rightChild] < mVector[isLowest]) {

		isLowest = rightChild;
	}


	if (isLowest != num) {

		swap(num, isLowest);
		heapifyNode(isLowest);

	}



}
void MinHeap::swap(int lhs, int rhs) {



	int temp = mVector[lhs];
	mVector[lhs] = mVector[rhs];
	mVector[rhs] = temp;

}
MinHeap::MinHeap() {
	// empty constructor
}
int MinHeap::getParentIndex(int index) {
	return  (index - 1) / 2;

}
int MinHeap::getLeftChildIndex(int index) {
	return (2 * index) + 1;
}
int MinHeap::getRightChildIndex(int index) {
	return (2 * index) + 2;
}
void MinHeap::insert(int num) {

	mVector.push_back(num);
	int location = mVector.size()-1;
	int parent = mVector[getParentIndex(location)];
	while (mVector[location] < parent) {

		swap(location, getParentIndex(location));
		location = getParentIndex(location);
		parent = mVector[getParentIndex(location)];
		



	}

}
void MinHeap::push_back(int num) {
	mVector.push_back(num);
}
int MinHeap::remove() {
	
	int temp = mVector.size() -1;
	swap(temp, 0);
	int last = mVector.pop_back();
	heapifyNode(0);


	return last;



}
int MinHeap::peek() const {
	return mVector.at(0);
}
bool MinHeap::isEmpty() const {

	if (mVector.size() == 0) {
		return true;
	}
	return false;

}
