#include <iostream>
#include <fstream>
#include <string>
#include "minheap.h"
#include "vector.hpp"


int main() {
	// file read and file name vars
	std::ifstream userFile;
	std::string fileName;


	//let user pick the file
	std::cout << "Heap Sort \n";
	std::cout << "Enter a filename: ";
	std::cin >> fileName;



	// declare vars used to read from file
	vector<int> vectorElements;
	MinHeap heapElements;
	std::string fileStuff;
	userFile.open(fileName);

	// create vars used for reading file
	int fileNum;
	int size;
	
	// gets first number from file which is the size # of ints
	userFile >> size;
	if (!userFile) {
		throw std::logic_error("File did not open, wrong file name");
	}
	
	// goes to the end of file inserting all the ints in the heap
	while (!userFile.eof()) {
		
		userFile >> fileNum;
		
		heapElements.insert(fileNum);
		

	}
	
	// checks if the heap is empty which it shouldnt be and it removes all elements while putting them into vector
	while (heapElements.isEmpty() == false) {

		int temp = heapElements.remove();
		vectorElements.push_back(temp);
	}


	
		

	// prints out vector sorted
	for (int i = 0; i < size; i++) {

		std::cout << vectorElements[i] << "\n";
	
}
	
	
		// checks to see if it was printed or not, it it wasnt then it is false
	if (vectorElements.isSorted() == true) {

		std::cout << "Vector is sorted";
		std::cout << "\n";
	}
	else {
		std::cout << "Vector is not sorted";
		std::cout << "\n";
	}


	// closes file for safety
	userFile.close();


	system("pause");
	return 0;
}