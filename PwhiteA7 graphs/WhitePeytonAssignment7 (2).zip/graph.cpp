#include "graph.h"
#include <iostream>

//constructor that sets all params and the array as a one d array
WGraph::WGraph(int v) {
	mVertices = v;
	mGraph = new int[v*v];
	for (int i = 0; i < mVertices*mVertices; i++) {
		mGraph[i] = 0;
	}

}
// calls copy function 
WGraph::WGraph(const WGraph &g)
{
	copy(g);
}
// deletes array
WGraph::~WGraph() {
	delete[] mGraph;
}
// copys one graph to another, used for transpose in main
void WGraph::copy(const WGraph& g) {

	mVertices = g.mVertices;
	mGraph = new int[mVertices*mVertices];
	for (int i = 0; i < mVertices*mVertices; i++) {

		mGraph[i] = g.mGraph[i];

	}

}
// checks for vertex in range 
void WGraph::checkForVertexInRange(int i) const {

	if (i >= mVertices || i < 0) {
		throw std::logic_error("Error vertex not in range");
	}

}
// sees if graph is to another and sets the array
bool WGraph::operator==(const WGraph& g) const {

	bool answer = false;
	if (g.mVertices == mVertices){

		for (int i = 0; i < mVertices * mVertices; i++)

			if (g.mGraph[i] == mGraph[i]){

				answer = true;
			}
	}
	return answer;
}
// copys the array graph 
//reminder look on HR for visualization
WGraph& WGraph::operator=(const WGraph& g) {

	if (this != &g) {
		delete[] mGraph;
		copy(g);

	}
	return *this;
}
// sets three params simple set
void WGraph::set(int i, int k, int w) {
	mGraph[i * mVertices + k] = w;

}
// sets two params simple set
void WGraph::set(int i, int k) {
	checkForVertexInRange(i);
	checkForVertexInRange(k);
	set(i, k, 1);
}
// get be sure to check for vertex and throw error
int WGraph::get(int i, int k)const {

	checkForVertexInRange(i);
	checkForVertexInRange(k);
	return mGraph[i * mVertices + k];

} 
// is a bool funciotn then returns the true or false reverts back to the main.cpp
// look back on notes slide 21
bool WGraph::isAntisymmetric() const {
	bool isAntiSym = false;
	
	for (int i = 0; i < mVertices; i++){

		for (int j = 0; j < mVertices; j++){

			if (get(i, j) != get(j, i)){

				if (get(i, j) == 1 && get(j, i) == 0) {
					isAntiSym = true;
				}
				else {
					return false;
				}
			}
		}
	}
	return isAntiSym;
}
// opposite of antisymetroc, look back on notes slide 22 
bool WGraph::isSymmetric() const
{
	bool isSym = false;
	for (int i = 0; i < mVertices; i++){

		for (int j = 0; j < mVertices; j++){

			if (get(i, j) == get(j, i)) {

				isSym = true;
			}
			else {
				return false;
			}
		}
	}
	return isSym;
}
//notes slide 20
bool WGraph::isReflexive() const
{
	bool isReflex = true;
	for (int i = 0; i < mVertices; i++){

		if (get(i, i) == 0) {

			isReflex = false;
		}
	}
	return isReflex;
}
// sets the transpose of the regular graph
// Reminder: got help from nathan
WGraph WGraph::transpose() const
{
	WGraph transM(mVertices);
	
	for (int i = 0; i < mVertices; i++){

		for (int j = 0; j < mVertices; j++){
			int getParam = get(i, j);
			transM.set(j, i,getParam);
		}
	}
	return transM;
}
// returns num of vertices
int WGraph::GetNumVertices() const {

	return mVertices;
}
// look in my c++ book page 256 for reminder
std::ostream& operator<<(std::ostream& os, const WGraph& g)
{
	for (int i = 0; i < g.mVertices; i++){

		for (int j = 0; j < g.mVertices; j++){
			os << g.get(i, j) << " ";
		}
		std::cout << "\n";
	}
	return os;
}