#include <iostream>
#include "graph.h"
/*
Peyton White
3250 
assignment 8 graphs 
4/15/2018
this program creats a Wgraph and allows user to create verts and edges and tells them if it is reflexive and stuff

*/


void menu();

int main() {

	menu();


	std::cout << "\n";
	std::cout << "Thank you for using Peyton's program \n";
	system("pause");
	return 0;
}

void menu() {

	// user chooses num of edges and vertices
	int numOfEdges;
	int numOfVert;
	std::cout << "Enter a number of vertices in the graph: ";
	std::cin >> numOfVert;
	std::cout << "Enter a number of edges in the graph: ";
	std::cin >> numOfEdges;

	// graph.h instance that sets size with vertices of user pick
	WGraph graph(numOfVert);
	// this instance is used for the transpose call in the menu to pass through the operator call
	WGraph transM(numOfVert);
	// lets user choose vertexes
	int choiceStart;
	int choiceEnd;
	for (int i = 0; i < numOfEdges; i++) {
		std::cout << "Enter a starting vertex: ";
		std::cin >> choiceStart;
		std::cout << "Enter a ending vertex: ";
		std::cin >> choiceEnd;
		// sets the graph
		graph.set(choiceStart, choiceEnd);
	}
	// uses operator to visualize graph 
	operator<<(std::cout, graph);
	std::cout << "Reflexive?: ";
	if (graph.isReflexive()) {
		std::cout << "Yes \n";
	}
	else {
		std::cout << "No \n";
	}

	std::cout << "Symmetric?: ";
	if (graph.isSymmetric()) {
		std::cout << "Yes \n";
	}
	else {
		std::cout << "No \n";
	}

	std::cout << "AntiSymmetric?: ";
	if (graph.isAntisymmetric()) {
		std::cout << "Yes \n";
	}
	else {
		std::cout << "No \n";
	}

	// calls the transpose function and puts it in a var and passes it through the operator
	std::cout << "Transpose Graph: \n";
	transM = graph.transpose();
	operator<<(std::cout, transM);



}